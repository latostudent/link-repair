## Descripción
**Desafios 1 y 2 para la prueba tecnica de WEREMOTE:** plugin desarrollado por **Carlos La Torre**.

## Detalles
- Plugin que ejecuta cada 60 minutos una funcion que detecta los enlaces que no funcionan correctamente y registra los detalles en un custom post type.
- Plugin que te permite mostrar las citas adicionales de un post mediante un shortcode

