
<body>
    
<div class='wrap'>
    <h1>EXTRA QUOTES</h1>

<h2>Plugin para mostrar las citas adicionales en una entrada mediante un SHORTCODE</h2>

</div>

<div class="postbox" style="width:500px">
    <div class="inside">
    <h3>Descripción:</h3>
    <span>Debajo del editor del post aparecera un campo adicional para insertar las citas</span>
    <hr>
    <p>Para mostrar las citas del post actual utilice el shortcode: <b>[extraquotes]</b></p>
    <p>Para mostrar las citas de un post en especifico utilice el shortcode con el atributo "post", ejemplo: <b>[extraquotes post="9"]</b></p>
    </div>
</div>

</body>
