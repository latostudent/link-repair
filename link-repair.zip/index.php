<?php // Silence is golden

